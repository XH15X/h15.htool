# H.toolkit
BETA H.toolkit es una herramienta programada en bash que nos permite de manera automatizada llevar a cabo tareas de hacking, tal como DESCRIPTAR SERVIDOR FTP, ATAQUE A WIFI, TROYANOS, EXPLOIT, ESCANER,INYECCION SQL, Y EL SMB RELAY solo con los datos de la victima, en el cual esta esta herramienta esta en el proceso BETA 
